import { Model, Skybox, ThirdPersonCamera, useLoop, World, Cube, useSpring } from "lingo3d-react"
import { useRef, useState } from "react"
import "./App.css"

const App = () => {
  const characterRef = useRef()
  const [running, setRunning] = useState(false)
  const [markerPosition, setMarkerPosition] = useState({ x: 0, y: 0, z: 0 })

  //springs animate values
  const markerSpringX = useSpring({ to: markerPosition.x, bounce: 0 })
  const markerSpringY = useSpring({ to: markerPosition.y, bounce: 0 })
  const markerSpringZ = useSpring({ to: markerPosition.z, bounce: 0 })

  useLoop(() => {
    const lookAtPosition = { x: markerSpringX.get(), y: characterRef.current.y, z: markerSpringZ.get() }
    characterRef.current.lookAt(lookAtPosition)
  })

  useLoop(() => {
    characterRef.current.moveForward(-6)
  }, running)

  return (
    <>
      <World>
        <Cube id="marker" x={markerSpringX} y={markerSpringY} z={markerSpringZ} />
        <Model src="Grassland.glb" scale={270} physics="map" onClick={e => {
          setMarkerPosition(e.point)
          setRunning(true)
        }} />
        <ThirdPersonCamera active minPolarAngle={135} maxPolarAngle={135} lockTargetRotation="follow">
          <Model
            ref={characterRef}
            src="person.glb"
            y={200}
            z={-150}
            animations={{ idleAnimation: "idle.fbx", runningAnimation: "running.fbx" }}
            animation={ running ? "runningAnimation" : "idleAnimation" }
            physics="character"
            intersectIDs={["marker"]}
            onIntersect={() => setRunning(false)}
            onIntersectOut={() => setRunning(true)}
          />
        </ThirdPersonCamera>
        <Skybox texture="skybox.jpg" />
      </World>
    </>
  )
}

export default App